#!/bin/sh
sbatch --job-name=Job85  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job85/Job85.log' --export=NONE --ntasks=32 --cpus-per-task=1 --ntasks-per-node=32 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p checkpt -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job85/tp53df6969_6e55_43b5_af70_7f735c7f741c.sh'
