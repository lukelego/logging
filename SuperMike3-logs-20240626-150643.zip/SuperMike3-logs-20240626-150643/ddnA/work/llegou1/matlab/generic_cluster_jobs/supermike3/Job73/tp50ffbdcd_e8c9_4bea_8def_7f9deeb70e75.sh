#!/bin/sh
sbatch --job-name=Job73.1  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job73/Task1.log' --export=NONE --ntasks=1 --cpus-per-task=1 --ntasks-per-node=1 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p workq -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job73/tp22b2595c_08a6_4898_9cc5_75ade0e7ac67.sh'
