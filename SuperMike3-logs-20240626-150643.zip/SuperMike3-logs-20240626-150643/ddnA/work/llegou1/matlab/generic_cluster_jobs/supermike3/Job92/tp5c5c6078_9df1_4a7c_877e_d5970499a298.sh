#!/bin/sh
sbatch --job-name=Job92  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job92/Job92.log' --export=NONE --ntasks=32 --cpus-per-task=1 --ntasks-per-node=32 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p workq -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job92/tp0cca63b3_fc8e_409c_b740_ceec774c6d06.sh'
