#!/bin/sh
# Filter test: #SBATCH test
export PARALLEL_SERVER_DECODE_FUNCTION='parallel.cluster.generic.communicatingDecodeFcn'
export PARALLEL_SERVER_STORAGE_CONSTRUCTOR='makeFileStorageObject'
export PARALLEL_SERVER_JOB_LOCATION='Job92'
export PARALLEL_SERVER_MATLAB_EXE='/home/packages/license/matlab/r2023b/bin/worker'
export PARALLEL_SERVER_MATLAB_ARGS='-parallel'
export PARALLEL_SERVER_DEBUG='false'
export MLM_WEB_LICENSE='false'
export PARALLEL_SERVER_STORAGE_LOCATION='PC{}:UNIX{/work/llegou1/matlab/generic_cluster_jobs/supermike3}:'
export PARALLEL_SERVER_CMR='/home/packages/license/matlab/r2023b'
export PARALLEL_SERVER_TOTAL_TASKS='32'
export PARALLEL_SERVER_NUM_THREADS='1'
'/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job92/communicatingJobWrapper.sh'
