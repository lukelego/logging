#!/bin/sh
sbatch --job-name=Job84  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job84/Job84.log' --export=NONE --ntasks=32 --cpus-per-task=1 --ntasks-per-node=32 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p checkpt -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job84/tpe545885b_a5ac_4fa6_9527_a7d1d8f25396.sh'
