#!/bin/sh
sbatch --job-name=Job80  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job80/Job80.log' --export=NONE --ntasks=32 --cpus-per-task=1 --ntasks-per-node=32 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p checkpt -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job80/tpc60fd058_2cfb_4c61_8533_89e04a2c1a80.sh'
