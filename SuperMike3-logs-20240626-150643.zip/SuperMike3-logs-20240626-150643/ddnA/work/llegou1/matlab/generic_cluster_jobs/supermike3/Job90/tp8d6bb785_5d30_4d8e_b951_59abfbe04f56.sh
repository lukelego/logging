#!/bin/sh
sbatch --job-name=Job90.1  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job90/Task1.log' --export=NONE --ntasks=1 --cpus-per-task=1 --ntasks-per-node=1 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p workq -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job90/tpceacdc01_4221_4203_adfa_8dd3613e2d36.sh'
