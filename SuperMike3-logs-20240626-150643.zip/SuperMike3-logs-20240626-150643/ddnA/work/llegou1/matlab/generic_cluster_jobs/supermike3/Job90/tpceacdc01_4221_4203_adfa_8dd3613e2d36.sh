#!/bin/sh
# Filter test: #SBATCH test
export PARALLEL_SERVER_DECODE_FUNCTION='parallel.cluster.generic.independentDecodeFcn'
export PARALLEL_SERVER_STORAGE_CONSTRUCTOR='makeFileStorageObject'
export PARALLEL_SERVER_JOB_LOCATION='Job90'
export PARALLEL_SERVER_MATLAB_EXE='/home/packages/license/matlab/r2023b/bin/worker'
export PARALLEL_SERVER_DEBUG='false'
export MLM_WEB_LICENSE='false'
export PARALLEL_SERVER_STORAGE_LOCATION='PC{}:UNIX{/work/llegou1/matlab/generic_cluster_jobs/supermike3}:'
export PARALLEL_SERVER_TASK_LOCATION='Job90/Task1'
'/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job90/independentJobWrapper.sh'
