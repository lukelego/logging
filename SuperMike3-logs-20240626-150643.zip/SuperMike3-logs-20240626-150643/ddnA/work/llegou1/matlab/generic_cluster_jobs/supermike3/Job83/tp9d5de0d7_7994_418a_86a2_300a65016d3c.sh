#!/bin/sh
sbatch --job-name=Job83  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job83/Job83.log' --export=NONE --ntasks=32 --cpus-per-task=1 --ntasks-per-node=32 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p checkpt -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job83/tpae8d46d7_a9c5_468b_9fa9_e88601472bed.sh'
