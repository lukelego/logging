#!/bin/sh
sbatch --job-name=Job87.1  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job87/Task1.log' --export=NONE --ntasks=1 --cpus-per-task=1 --ntasks-per-node=1 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p workq -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job87/tp42677ef6_30c4_405f_878d_765e3df9f93b.sh'
