#!/bin/sh
sbatch --job-name=Job79  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job79/Job79.log' --export=NONE --ntasks=11712 --cpus-per-task=1 --ntasks-per-node=32 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p checkpt -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job79/tpd3de0d3f_4490_4669_82a0_609152013694.sh'
