#!/bin/sh
sbatch --job-name=Job91  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job91/Job91.log' --export=NONE --ntasks=4 --cpus-per-task=1 --ntasks-per-node=4 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p workq -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job91/tp249608aa_750f_49c8_a597_2402275df9a0.sh'
