#!/bin/sh
sbatch --job-name=Job57  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job57/Job57.log' --export=NONE --ntasks=10 --cpus-per-task=1 --ntasks-per-node=10 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p workq -t 00:10:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job57/tpb225994a_be45_4bc6_adea_3eaccd5cbd5c.sh'
