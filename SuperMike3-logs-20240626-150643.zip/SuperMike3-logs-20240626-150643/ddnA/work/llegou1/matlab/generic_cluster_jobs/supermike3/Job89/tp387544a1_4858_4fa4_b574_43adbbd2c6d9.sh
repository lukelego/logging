#!/bin/sh
sbatch --job-name=Job89  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job89/Job89.log' --export=NONE --ntasks=32 --cpus-per-task=1 --ntasks-per-node=32 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p workq -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job89/tpc6520399_f93b_4fe7_bf58_686149dc05e0.sh'
