#!/bin/sh
sbatch --job-name=Job88  --output='/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job88/Job88.log' --export=NONE --ntasks=4 --cpus-per-task=1 --ntasks-per-node=4 --ntasks-per-core=1 --mem-per-cpu=4gb -A hpc_nanoph11 -p workq -t 00:20:00 '/work/llegou1/matlab/generic_cluster_jobs/supermike3/Job88/tpd17e1f86_e018_49be_862e_a4c6176ee967.sh'
